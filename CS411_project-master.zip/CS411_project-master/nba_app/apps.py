from django.apps import AppConfig


class NbaAppConfig(AppConfig):
    name = 'nba_app'
